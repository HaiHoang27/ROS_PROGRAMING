#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import Float32, String, Float32MultiArray

def talker():
    pub = rospy.Publisher('chatter', Float32, queue_size=10)
    pub_theta = rospy.Publisher('theta', Float32, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    th = 3.14
    rate = rospy.Rate(10) # 10hz
    th = th + 0.1
    while not rospy.is_shutdown():
        hello_str = 1.2345678
        #rospy.loginfo(th)
        pub_theta.publish(th)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass