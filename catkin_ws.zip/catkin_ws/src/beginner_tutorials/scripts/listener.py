#!/usr/bin/env python
import rospy
from std_msgs.msg import Float32, String, Float32MultiArray

def callback(data):
    global data_ser
    data_ser = data.data
    # print(data_ser)
    rospy.loginfo(data.data)
    
def listener():
    global data_ser
    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener', anonymous=True)


    #th = rospy.Subscriber("theta", Float32, callback, queue_size=10)
    th = rospy.Subscriber("theta", Float32, callback, queue_size=10)
    #rospy.loginfo(th)
    
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()