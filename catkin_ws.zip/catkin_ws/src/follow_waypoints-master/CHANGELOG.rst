^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package follow_waypoints
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2017-07-14)
------------------
* Added support for emptying the waypoint queue
* Update package.xml
* Update README.md

0.2.0 (2017-07-09)
------------------
* Update README.md
* Major update

0.1.0 (2017-07-09)
------------------
* first release